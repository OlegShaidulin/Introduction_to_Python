count_home_works = 12
count_hour = 1.5
course_name = 'Python'
time_for_one_lesson = 1.5/12
print(f'Курс: {course_name} всего задач: {count_home_works}, затрачено {count_hour} часов, время на одно занятие {time_for_one_lesson} часа')